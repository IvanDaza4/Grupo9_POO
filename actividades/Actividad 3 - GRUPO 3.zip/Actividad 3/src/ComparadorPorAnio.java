import java.util.Comparator;

public class ComparadorPorAnio implements Comparator<Libro> {
    @Override
    public int compare(Libro a, Libro b) {
        return Integer.compare(b.getAnioPublicacion(), a.getAnioPublicacion());
    }
}