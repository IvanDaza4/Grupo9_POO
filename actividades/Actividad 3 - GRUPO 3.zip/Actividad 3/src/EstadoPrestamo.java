public enum EstadoPrestamo {
    ACTIVO,
    DEVUELTO,
    VENCIDO
}
