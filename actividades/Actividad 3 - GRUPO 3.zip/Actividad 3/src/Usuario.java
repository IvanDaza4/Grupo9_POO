import java.util.Objects;

public class Usuario {
    private final String dni;
    private String nombre;
    private String correo;

    public Usuario(String dni, String nombre, String correo) throws DatosInvalidosException {
        if (dni == null || dni.isBlank())
            throw new DatosInvalidosException("El DNI no puede estar vacio.");
        if (nombre == null || nombre.isBlank())
            throw new DatosInvalidosException("El nombre no puede estar vacio.");
        if (correo == null || !correo.contains("@"))
            throw new DatosInvalidosException("Correo invalido: " + correo);
        this.dni = dni;
        this.nombre = nombre;
        this.correo = correo;
    }

    // Dos usuarios son el mismo si tienen el mismo DNI
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario)) return false;
        Usuario usuario = (Usuario) o;
        return dni.equals(usuario.dni);
    }

    @Override
    public int hashCode() { return Objects.hash(dni); }

    @Override
    public String toString() { return nombre + " (DNI " + dni + ")"; }

    public String getDni() { return dni; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }
}