import java.util.*;

public class Biblioteca {
    private final List<Libro> catalogo = new ArrayList<>();
    private final Set<Usuario> usuarios = new HashSet<>();
    private final Map<String, List<Prestamo>> prestamosPorDni = new HashMap<>();
    private static final int DIAS_PLAZO = 14;

    public void agregarLibro(Libro libro) { catalogo.add(libro); }

    
    public boolean registrarUsuario(Usuario usuario) { return usuarios.add(usuario); }

    public Prestamo realizarPrestamo(String dni, String isbn)
            throws UsuarioNoRegistradoException, LibroInexistenteException,
            LibroNoDisponibleException {
        Usuario usuario = buscarUsuario(dni);
        if (usuario == null)
            throw new UsuarioNoRegistradoException(
                    "El usuario con DNI " + dni + " no esta registrado.");
        Libro libro = buscarLibro(isbn);
        if (libro == null)
            throw new LibroInexistenteException("No existe un libro con ISBN " + isbn + ".");
        libro.prestarEjemplar(); // puede lanzar LibroNoDisponibleException
        Prestamo prestamo = new Prestamo(usuario, libro, DIAS_PLAZO);
        prestamosPorDni.computeIfAbsent(dni, k -> new ArrayList<>()).add(prestamo);
        return prestamo;
    }

    public void devolverLibro(String dni, String isbn) throws UsuarioNoRegistradoException {
        List<Prestamo> prestamos = prestamosPorDni.get(dni);
        if (prestamos == null)
            throw new UsuarioNoRegistradoException(
                    "El usuario " + dni + " no tiene prestamos registrados.");
        for (Prestamo p : prestamos) {
            if (p.getLibro().getIsbn().equals(isbn)
                    && p.getEstado() == EstadoPrestamo.ACTIVO) {
                p.marcarDevuelto();
                p.getLibro().devolverEjemplar();
                return;
            }
        }
    }

    public int limpiarPrestamosDevueltos(String dni) {
        List<Prestamo> prestamos = prestamosPorDni.get(dni);
        if (prestamos == null) return 0;
        int eliminados = 0;
        Iterator<Prestamo> it = prestamos.iterator();
        while (it.hasNext()) {
            Prestamo p = it.next();
            if (p.getEstado() == EstadoPrestamo.DEVUELTO) {
                it.remove();
                eliminados++;
            }
        }
        return eliminados;
    }

    public List<Libro> listarPorTitulo() {
        List<Libro> copia = new ArrayList<>(catalogo);
        Collections.sort(copia);          
        return copia;
    }

    public List<Libro> listarPorAnio() {
        List<Libro> copia = new ArrayList<>(catalogo);
        copia.sort(new ComparadorPorAnio()); 
        return copia;
    }

    public List<Prestamo> prestamosDe(String dni) {
        return prestamosPorDni.getOrDefault(dni, Collections.emptyList());
    }

    private Usuario buscarUsuario(String dni) {
        for (Usuario u : usuarios) if (u.getDni().equals(dni)) return u;
        return null;
    }

    private Libro buscarLibro(String isbn) {
        for (Libro l : catalogo) if (l.getIsbn().equals(isbn)) return l;
        return null;
    }
}