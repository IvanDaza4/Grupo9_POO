public class Main {
    public static void main(String[] args) throws Exception {

        Biblioteca biblioteca = new Biblioteca();

        
        Libro l1 = new Libro("1", "El Aleph", "Borges", 1949, "Cuento", 2);
        Libro l2 = new Libro("2", "Rayuela", "Cortazar", 1963, "Novela", 1);
        Libro l3 = new Libro("3", "Ficciones", "Borges", 1944, "Cuento", 0);
        Libro l4 = new Libro("4", "Boquitas pintadas", "Puig", 1969, "Novela", 3);
        biblioteca.agregarLibro(l1);
        biblioteca.agregarLibro(l2);
        biblioteca.agregarLibro(l3);
        biblioteca.agregarLibro(l4);

        
        Usuario u1 = new Usuario("30111222", "Ana Lopez", "ana@mail.com");
        Usuario u2 = new Usuario("28999888", "Beto Ruiz", "beto@mail.com");
        Usuario u3 = new Usuario("33444555", "Caro Diaz", "caro@mail.com");
        biblioteca.registrarUsuario(u1);
        biblioteca.registrarUsuario(u2);
        biblioteca.registrarUsuario(u3);

        
        boolean repetido = biblioteca.registrarUsuario(
                new Usuario("30111222", "Ana Lopez", "ana@mail.com"));
        System.out.println("Se registro el usuario duplicado? " + repetido);

        
        biblioteca.realizarPrestamo("30111222", "1");
        System.out.println("Ejemplares de El Aleph: " + l1.getEjemplaresDisponibles());

        
        try {
            biblioteca.realizarPrestamo("28999888", "3");
        } catch (LibroNoDisponibleException e) {
            System.out.println("Excepcion controlada: " + e.getMessage());
        } finally {
            // El finally se ejecuta SIEMPRE: haya o no excepcion
            System.out.println("[auditoria] Intento de prestamo finalizado.");
        }

        
        System.out.println("\n-- Por titulo (orden natural) --");
        for (Libro l : biblioteca.listarPorTitulo()) System.out.println(l);

        System.out.println("\n-- Por anio descendente (Comparator) --");
        for (Libro l : biblioteca.listarPorAnio()) System.out.println(l);

    
        biblioteca.devolverLibro("30111222", "1");
        int depurados = biblioteca.limpiarPrestamosDevueltos("30111222");
        System.out.println("\nPrestamos devueltos depurados: " + depurados);
    }
}