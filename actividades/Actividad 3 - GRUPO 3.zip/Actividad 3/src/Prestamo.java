import java.time.LocalDate;

public class Prestamo {
    private final Usuario usuario;
    private final Libro libro;
    private final LocalDate fechaPrestamo;
    private final LocalDate fechaDevolucionEstimada;
    private EstadoPrestamo estado;

    public Prestamo(Usuario usuario, Libro libro, int diasPlazo) {
        this.usuario = usuario;
        this.libro = libro;
        this.fechaPrestamo = LocalDate.now();
        this.fechaDevolucionEstimada = this.fechaPrestamo.plusDays(diasPlazo);
        this.estado = EstadoPrestamo.ACTIVO;
    }

    public void marcarDevuelto() { this.estado = EstadoPrestamo.DEVUELTO; }

    public boolean estaVencido() {
        return estado == EstadoPrestamo.ACTIVO
                && LocalDate.now().isAfter(fechaDevolucionEstimada);
    }

    @Override
    public String toString() {
        return usuario.getNombre() + " -> " + libro.getTitulo() + " [" + estado + "]";
    }

    public Usuario getUsuario() { return usuario; }
    public Libro getLibro() { return libro; }
    public LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public LocalDate getFechaDevolucionEstimada() { return fechaDevolucionEstimada; }
    public EstadoPrestamo getEstado() { return estado; }
}