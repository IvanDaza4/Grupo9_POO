import java.time.Year;

public class Libro implements Comparable<Libro> {
    private final String isbn;
    private String titulo;
    private String autor;
    private int anioPublicacion;
    private String genero;
    private int ejemplaresDisponibles;

    public Libro(String isbn, String titulo, String autor,
                 int anioPublicacion, String genero, int ejemplaresDisponibles)
            throws DatosInvalidosException {
        if (isbn == null || isbn.isBlank())
            throw new DatosInvalidosException("El ISBN no puede estar vacio.");
        if (titulo == null || titulo.isBlank())
            throw new DatosInvalidosException("El titulo no puede estar vacio.");
        if (autor == null || autor.isBlank())
            throw new DatosInvalidosException("El autor no puede estar vacio.");
        if (anioPublicacion < 1450 || anioPublicacion > Year.now().getValue())
            throw new DatosInvalidosException("Anio de publicacion invalido: " + anioPublicacion);
        if (ejemplaresDisponibles < 0)
            throw new DatosInvalidosException("La cantidad de ejemplares no puede ser negativa.");
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.genero = genero;
        this.ejemplaresDisponibles = ejemplaresDisponibles;
    }

    // Comportamiento propio del libro (patron Experto en Informacion)
    public boolean hayDisponibilidad() { return ejemplaresDisponibles > 0; }

    public void prestarEjemplar() throws LibroNoDisponibleException {
        if (!hayDisponibilidad())
            throw new LibroNoDisponibleException("No hay ejemplares disponibles de: " + titulo);
        ejemplaresDisponibles--;
    }

    public void devolverEjemplar() { ejemplaresDisponibles++; }

    // Orden natural: titulo, y como desempate autor
    @Override
    public int compareTo(Libro otro) {
        int porTitulo = this.titulo.compareToIgnoreCase(otro.titulo);
        if (porTitulo != 0) return porTitulo;
        return this.autor.compareToIgnoreCase(otro.autor);
    }

    // Identidad por ISBN
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Libro)) return false;
        Libro libro = (Libro) o;
        return isbn.equals(libro.isbn);
    }

    @Override
    public int hashCode() { return isbn.hashCode(); }

    @Override
    public String toString() {
        return String.format("\"%s\" (%s, %d) - ejemplares: %d",
                titulo, autor, anioPublicacion, ejemplaresDisponibles);
    }

    public String getIsbn() { return isbn; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public int getAnioPublicacion() { return anioPublicacion; }
    public String getGenero() { return genero; }
    public int getEjemplaresDisponibles() { return ejemplaresDisponibles; }
}